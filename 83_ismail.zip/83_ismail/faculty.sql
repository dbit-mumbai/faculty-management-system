-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2017 at 05:10 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `faculty`
--

-- --------------------------------------------------------

--
-- Table structure for table `industrialinfo`
--

CREATE TABLE IF NOT EXISTS `industrialinfo` (
  `compname` varchar(20) NOT NULL,
  `yoe` varchar(10) NOT NULL,
  `doj` date NOT NULL,
  `dol` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `industrialinfo`
--

INSERT INTO `industrialinfo` (`compname`, `yoe`, `doj`, `dol`) VALUES
('L and T', '4', '2017-04-01', '2017-04-14');

-- --------------------------------------------------------

--
-- Table structure for table `personalinfo`
--

CREATE TABLE IF NOT EXISTS `personalinfo` (
  `fname` varchar(20) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `gen` text NOT NULL,
  `num` int(10) NOT NULL,
  `em` varchar(15) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `desg` varchar(20) NOT NULL,
  `doj` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `personalinfo`
--

INSERT INTO `personalinfo` (`fname`, `mname`, `lname`, `dob`, `gen`, `num`, `em`, `dept`, `desg`, `doj`) VALUES
('Ismail', 'abc', 'sayyad', '2017-04-02', 'male', 56565656, 'sdasd@sd.com', 'IT', 'T.A', '2017-04-01');

-- --------------------------------------------------------

--
-- Table structure for table `proundertaken`
--

CREATE TABLE IF NOT EXISTS `proundertaken` (
  `proname` varchar(20) NOT NULL,
  `spec` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `proundertaken`
--

INSERT INTO `proundertaken` (`proname`, `spec`) VALUES
('Toll', 'none');

-- --------------------------------------------------------

--
-- Table structure for table `qualificationinfo`
--

CREATE TABLE IF NOT EXISTS `qualificationinfo` (
  `spec` varchar(20) NOT NULL,
  `degree` varchar(20) NOT NULL,
  `yoc` varchar(20) NOT NULL,
  `university` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qualificationinfo`
--

INSERT INTO `qualificationinfo` (`spec`, `degree`, `yoc`, `university`) VALUES
('none', 'be', '0000-00-00', 'mumbai');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
