<!DOCTYPE html>
<html>
<head>
	<title>Faculty Management System </title>
	<style>
	body {
	        background-color:#add8e6;
		fieldset {
    		display: block;
			width: 50%;
			text-align:center;
			margin-left: 25%;
    		margin-right: 25%;
				}
		button:hover {
			 background-color:#1E90FF;
				}
	</style>
<style>
		input,select,button{
			padding: 5px 8px;
			margin: 4px 0;
			display: inline-block;
			border: 1px solid #ccc;
			border-radius: 3px;
			box-sizing: border-box;
		}
	
		input[type=text,email,password,date]{
			width:80%;
		}

		input[type=submit] {
			background-color:#1E90FF;
			color: white;
			padding: 5px 8px;
			margin: 4px 0;
			border: none;
			border-radius: 3px;
			cursor: pointer;
		}

		input[type=submit]:hover {
			background-color:#45a049;
		}

	</style>

	<style>
		legend{
			color:#1E90FF;
		}
		th{
		text-align:right;
		}

		td{
		text-align:left;
		}

		ul#m01 {
			list-style-type: none;
			margin: 1;
			padding: 1;
			overflow: hidden;
			background-color:#1E90FF;
		}

		li#m01 {
			float:left;
		}

		li#m01 a {
			display: block ;
			color: white;
			text-align: right;
			padding: 10px;
			text-decoration:none;
		}

		li#m01 a:hover {
			background-color: #191970;
			text-decoration:underline;
		}

		li#m01 a.active {
			background-color:blue;
		}
	</style>
<script src="myvalidate.js"></script> 


	


</head>
<h1>Faculty Management System </h1>
<br>
<form name="FMS" method="post">
	<fieldset>
		<legend>Personal Information</legend>
		
		<table align="center">
			<tr>
				<th>Name</td>
				<td>:</td>
				<td><input type="text" name="fname" onkeyup="limit(this,5);" onkeydown="limit(this)" ></td>
			
</tr>
			
			<tr>
				<th>Middle name</th>
				<td>:</td>
				<td><input type="text" name="mname" ></td>
			</tr>
		
			<tr>
				<th>Last Name</th>
				<td>:</td>
				<td><input type="text" name="lname"></td>
			</tr>
		
			<tr>
				<th>Date Of Birth</th>
				<td>:</td>
				<td><input type="Date" name="dob" ></td>
			</tr>
			<tr>
				<th>Gender</th>
				<td>:</td>
				<td><input type="radio" name="gen" value="male" checked>Male<input type="radio" name="gen" value="female" checked >Female<td>
			</tr>

			<tr>		
				<th>Contact</th>
				<td>:</td>
				<td><input type="text" id="contact" name="num" onkeyup="limit(this,10);"></td>
			</tr>

			<tr>
				<th>Email</th>
				<td>:</td>.
				<td><input type="email" name="em"></td>
			</tr>

			<tr>
				<th>Department</th>
				<td>:</td>
				<td><select name="dept" style="max-width:80%;"required>
						<option value="no" selected="">--Select Department--</option>
						<option value="IT" >Information Technology</option>
						<option value="COMPS">Computer Engineering</option>
						<option value="EXTC">Electronics and Telecommunications</option>
						<option value="MECH">Mechanical Engineering</option>
					</select></td>
			</tr>

				<tr>
				<th>Designation</th>
				<td>:</td>
				<td><select name="desg" style="max-width:80%;"required>
						<option value="no" selected="">--Select Designation--</option>
						<option value="T.A" >Teaching Assistant</option>
						<option value="A.P">Assistant Professor</option>
						<option value="A.Po">Associate Professor</option>
						<option value="Prof">Professor</option>
					</select></td>
			</tr>
					<tr>
				<th>Date Of Joining</th>
				<td>:</td>
				<td><input type="Date" name="doj" ></td>
			</tr>
		</table>
	</fieldset>

<br>

	<<fieldset>
		<legend>Qualification Information</legend>
		
		<table align="center">
			<tr>
				<th>Specification</td>
				<td>:</td>
				<td><input type="text" name="spec"></td>
			</tr>
			
			<tr>
				<th>Degree</th>
				<td>:</td>
				<td><input type="text" name="degree" ></td>
			</tr>
		
			<tr>
				<th>Year of Completion</th>
				<td>:</td>
				<td><input type="text" name="yoc"></td>
			</tr>

				<tr>
				<th>University</th>
				<td>:</td>
				<td><input type="text" name="university"></td>
			</tr>
		</table>
	</fieldset>


	<fieldset>
		<legend>Industrial Information</legend>
		
		<table align="center">
			<tr>
				<th>Company Name</td>
				<td>:</td>
				<td><input type="text" name="compname" onkeyup="limit(this,5);" onkeydown="limit(this)" ></td>
			</tr>
			
			<tr>
				<th>Year of Experience</th>
				<td>:</td>
				<td><input type="text" name="yoe" ></td>
			</tr>
				<tr>
				<th>Date Of Joining</th>
				<td>:</td>
				<td><input type="Date" name="doj" ></td>
			</tr>
			<tr>
				<th>Date Of Leaving</th>
				<td>:</td>
				<td><input type="Date" name="dol" ></td>
			</tr>
</table>
	</fieldset>

<fieldset>
		<legend>Project Undertaken</legend>
		
		<table align="center">
			<tr>
				<th>Project Name</td>
				<td>:</td>
				<td><input type="text" name="proname" onkeyup="limit(this,5);" onkeydown="limit(this)" ></td>
			</tr>
			
			<tr>
				<th>Specification</th>
				<td>:</td>
				<td><input type="text" name="spec" ></td>
			</tr>
</table>
	</fieldset>
</fieldset>
<?php
    
		
	if(isset($_POST['submit']))
{
$fname=$_POST["fname"];
$mname=$_POST["mname"];
$lname=$_POST["lname"];
$dob=$_POST["dob"];
$gen=$_POST["gen"];
$num=$_POST["num"];
$em=$_POST["em"];
$dept=$_POST["dept"];
$desg=$_POST["desg"];
$doj=$_POST["doj"];

$spec=$_POST["spec"];
$degree=$_POST["degree"];
$yoc=$_POST["yoc"];
$university=$_POST["university"];

$compname=$_POST["compname"];
$yoe=$_POST["yoe"];
$doj=$_POST["doj"];
$dol=$_POST["dol"];

$proname=$_POST["proname"];
$spec=$_POST["spec"];



include "connect.php";

include "display.php";

$sql = "INSERT INTO personalinfo VALUES('$fname','$mname','$lname','$dob','$gen','$num','$em','$dept','$desg','$doj')";
      $result = mysql_query($sql);
	  
$sql = "INSERT INTO qualificationinfo VALUES('$spec','$degree','$yoc','$university')";
      $result = mysql_query($sql);
	 
$sql = "INSERT INTO industrialinfo VALUES('$compname','$yoe','$doj','$dol')";
      $result = mysql_query($sql);

$sql = "INSERT INTO proundertaken VALUES('$proname','$spec')";
      $result = mysql_query($sql);
		
		echo "<h2><font color=green>Member successfully added</font></h2>";
}
?>
<center>
<table>
<?php
    
		
	if(isset($_POST['display']))
{

include "connect.php";

$sql = "Select * from personalinfo";
      
		$result = mysql_query($sql);
		   $row=mysql_num_rows($result);

if ($row > 0) {
    // output data of each row
		
	   echo "<tr><th>First Name</th><th>Middle Name</th><th>Last Name</th><th>Date of birth</th><th>Gender</th><th>Phone Number</th><th>Email id</th><th>Department</th><th>Designation</th><th>Date of joining</th></tr>";
    while($row =  mysql_fetch_assoc($result)) {
        echo "<tr><td>" . $row["fname"]."</td><td>" . $row["mname"]."</td><td>".$row["lname"]."</td><td>".$row["dob"]."</td><td>".$row["gen"]."</td><td>".$row["num"]."</td><td>".$row["em"]."</td><td>".$row["dept"]."</td><td>".$row["desg"]."</td><td>".$row["doj"]."</td></tr>";
    }

} else {
    echo "0 results";
}
}
?>
</table>
<br>
<input type="submit" value="Submit"  name="submit">
<input type="submit" value="Display"  name="display">
<input type="reset" value="Reset"><br>
</center>
</form>
</body>
</html>
